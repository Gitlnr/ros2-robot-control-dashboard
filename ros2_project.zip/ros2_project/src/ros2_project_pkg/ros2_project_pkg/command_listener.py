import rclpy
from rclpy.node import Node
from std_msgs.msg import String
import time

# This class creates a ROS2 node that listens for robot commands
class CommandListener(Node):
    def __init__(self):
        # Initialize the node with the name 'command_listener'
        super().__init__('command_listener')

        # Create a subscriber to listen to the 'robot_command' topic
        # It expects messages of type String and calls listener_callback when a message is received
        self.subscription = self.create_subscription(
            String,
            'robot_command',
            self.listener_callback,
            10  # Queue size
        )

    # This function is called every time a new message is received
    def listener_callback(self, msg):
        # Convert incoming command to uppercase for consistency
        command = msg.data.upper()

        # Get current timestamp
        ts = time.strftime('%Y-%m-%d %H:%M:%S')

        # Robot Arm commands: turn on colored lights
        if command in ["RED", "BLUE", "GREEN"]:
            print(f"[{ts}] --> Robot Arm: {command} light ON")

        # HubPilot commands: simulate robot movement operations
        elif command in ["MOVE", "LEFT", "RIGHT", "STOP"]:
            print(f"[{ts}] --> HubPilot: {command.capitalize()} started")
            
            # (Optional) Here you could add a delay to simulate operation time
            # time.sleep(2)

            # Log completion of the command
            print(f"[{ts}] --> HubPilot: {command.capitalize()} completed")

        # Handle unknown commands
        else:
            print(f"[{ts}] --> Unknown command: {command}")


# Main function to start the ROS2 node
def main(args=None):
    # Initialize ROS2 communication
    rclpy.init(args=args)

    # Create the CommandListener node
    node = CommandListener()

    # Keep the node running and listening for messages
    rclpy.spin(node)

    # Clean up and shut down when done
    node.destroy_node()
    rclpy.shutdown()


# Entry point of the script
if __name__ == '__main__':
    main()

