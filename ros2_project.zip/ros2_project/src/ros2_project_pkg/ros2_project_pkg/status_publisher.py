import rclpy
from rclpy.node import Node
from std_msgs.msg import String
import time
import threading

# Map commands to display names
action_map = {
    "MOVE": "Moving",
    "LEFT": "Moving towards left",
    "RIGHT": "Moving towards right",
    "STOP": "Stop"
}

class StatusPublisher(Node):
    def __init__(self):
        super().__init__('status_publisher')

        # Publisher
        self.publisher_ = self.create_publisher(String, 'robot_status', 10)

        # Subscriber for commands
        self.create_subscription(String, 'robot_command', self.command_callback, 10)

        # Track current operation
        self.operation_in_progress = False
        self.current_action = ""
        self.action_start_time = 0

        # Publish heartbeat every 2 seconds
        self.create_timer(2.0, self.publish_heartbeat)

    def command_callback(self, msg):
        command = msg.data.upper()
        if command in action_map:
            self.current_action = action_map[command]
            self.operation_in_progress = True
            self.action_start_time = time.time()

            # Publish "in progress" immediately
            ts = time.strftime('%Y-%m-%d %H:%M:%S')
            in_progress_msg = String()
            in_progress_msg.data = f"Vehicle {self.current_action} in progress: {ts}"
            self.publisher_.publish(in_progress_msg)
            self.get_logger().info(f"Published: {in_progress_msg.data}")

            # Publish "completed" after 5 seconds in a separate thread
            def complete_action(action):
                time.sleep(5)
                ts_done = time.strftime('%Y-%m-%d %H:%M:%S')
                completed_msg = String()
                completed_msg.data = f"Vehicle {action} completed: {ts_done}"
                self.publisher_.publish(completed_msg)
                self.get_logger().info(f"Published: {completed_msg.data}")
                self.operation_in_progress = False
                self.current_action = ""

            threading.Thread(target=complete_action, args=(self.current_action,)).start()

    def publish_heartbeat(self):
        # Only publish heartbeat if no operation in progress
        if not self.operation_in_progress:
            ts = time.strftime('%Y-%m-%d %H:%M:%S')
            msg = String()
            msg.data = f"Vehicle heartbeat: {ts}"
            self.publisher_.publish(msg)
            self.get_logger().info(f"Published: {msg.data}")


def main(args=None):
    rclpy.init(args=args)
    node = StatusPublisher()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()