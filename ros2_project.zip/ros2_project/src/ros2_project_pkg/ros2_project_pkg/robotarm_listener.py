import rclpy
from rclpy.node import Node
from std_msgs.msg import String
import time

# This class creates a ROS2 node that listens for Robot Arm commands
class RobotArmListener(Node):
    def __init__(self):
        # Initialize the node with the name 'robotarm_listener'
        super().__init__('robotarm_listener')

        # Create a subscription to the 'robot_command' topic
        # It listens for String messages and calls listener_callback when received
        self.subscription = self.create_subscription(
            String,
            'robot_command',
            self.listener_callback,
            10  # Queue size
        )

        # Keep reference to subscription (prevents it from being garbage collected)
        self.subscription

    # Callback function triggered when a message is received
    def listener_callback(self, msg):
        # Convert the received command to uppercase
        command = msg.data.upper()

        # Get current timestamp
        ts = time.strftime('%Y-%m-%d %H:%M:%S')

        # Check if the command is a valid Robot Arm color command
        if command in ["RED", "BLUE", "GREEN"]:
            # Print the action being performed
            print(f"[{ts}] --> Robot arm action: {command} light ON")


# Main function to start the ROS2 node
def main(args=None):
    # Initialize ROS2 communication
    rclpy.init(args=args)

    # Create the RobotArmListener node
    node = RobotArmListener()

    # Keep the node running and listening for messages
    rclpy.spin(node)

    # Clean up node resources before shutting down
    node.destroy_node()
    rclpy.shutdown()


# Entry point of the script
if __name__ == '__main__':
    main()