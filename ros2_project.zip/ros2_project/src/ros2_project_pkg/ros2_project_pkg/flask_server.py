from flask import Flask, request, jsonify, render_template
import rclpy
from rclpy.node import Node
from std_msgs.msg import String
import threading

# -----------------------------
# Flask App Setup
# -----------------------------
app = Flask(__name__)

# Store latest status (shared with UI)
latest_status = "Vehicle is PARKED"


# -----------------------------
# ROS2 Node Setup
# -----------------------------
rclpy.init(args=None)
ros_node = Node("flask_ros_node")

# Publisher → send commands to ROS2
publisher = ros_node.create_publisher(String, 'robot_command', 10)


# Subscriber → receive status from ROS2
def status_callback(msg):
    global latest_status
    latest_status = msg.data
    print(f"[Flask] Status Updated → {latest_status}")


ros_node.create_subscription(
    String,
    'robot_status',
    status_callback,
    10
)


# Run ROS2 in background thread
def ros_spin():
    rclpy.spin(ros_node)


threading.Thread(target=ros_spin, daemon=True).start()


# -----------------------------
# Flask Routes
# -----------------------------

# Home page
@app.route('/')
def home():
    return render_template('index.html')


# Send command to ROS2
@app.route('/send_command', methods=['POST'])
def send_command():
    data = request.get_json()

    if not data or 'command' not in data:
        return jsonify({"error": "Invalid request"}), 400

    command = data['command']

    # Publish to ROS2
    msg = String()
    msg.data = command
    publisher.publish(msg)

    print(f"[Flask] Command Sent → {command}")

    return jsonify({
        "status": "success",
        "command": command
    })


# Get latest robot status
@app.route('/status', methods=['GET'])
def get_status():
    return jsonify({
        "status": latest_status
    })


# -----------------------------
# Run Server
# -----------------------------
if __name__ == "__main__":
    print("🚀 Flask Server Running at http://localhost:5000")
    app.run(host="0.0.0.0", port=5000, debug=True)