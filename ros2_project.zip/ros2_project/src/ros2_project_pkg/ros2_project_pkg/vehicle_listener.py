import rclpy
from rclpy.node import Node
from std_msgs.msg import String
import time

# This class creates a ROS2 node that listens specifically for Vehicle-related commands
class VehicleListener(Node):
    def __init__(self):
        # Initialize the node with the name 'vehicle_listener'
        super().__init__('vehicle_listener')

        # Subscribe to the 'robot_command' topic
        # Calls command_callback whenever a message is received
        self.create_subscription(String, 'robot_command', self.command_callback, 10)

    # Callback function triggered when a message is received
    def command_callback(self, msg):
        # Convert command to uppercase for consistency
        command = msg.data.upper()

        # Get the current timestamp
        ts = time.strftime('%Y-%m-%d %H:%M:%S')

        # Map incoming commands to human-readable actions
        action_map = {
            "MOVE": "Moving",
            "LEFT": "Moving towards left",
            "RIGHT": "Moving towards right",
            "STOP": "Stop"
        }

        # Check if the command is a valid Vehicle command
        if command in action_map:
            action = action_map[command]

            # Print status message indicating the action has started
            print(f"Vehicle {action} in progress: {ts}")

            # Log the received command using ROS2 logger
            self.get_logger().info(f"Received Vehicle command: {command}")

            # Simulate task completion after 5 seconds using a separate thread
            def complete():
                time.sleep(5)  # Simulate operation delay
                ts_done = time.strftime('%Y-%m-%d %H:%M:%S')

                # Print completion message
                print(f"Vehicle {action} completed: {ts_done}")

            # Run the completion function in a new thread so it doesn't block the main node
            import threading
            threading.Thread(target=complete).start()


# Main function to start the ROS2 node (required for console_scripts entry point)
def main(args=None):
    # Initialize ROS2
    rclpy.init(args=args)

    # Create the VehicleListener node
    node = VehicleListener()

    # Keep the node running and listening for incoming messages
    rclpy.spin(node)

    # Clean up node resources when shutting down
    node.destroy_node()
    rclpy.shutdown()


# Entry point of the script
if __name__ == '__main__':
    main()