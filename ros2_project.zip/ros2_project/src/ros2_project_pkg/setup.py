from setuptools import find_packages, setup

package_name = 'ros2_project_pkg'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='rahul',
    maintainer_email='rahul@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    extras_require={
        'test': [
            'pytest',
        ],
    },
    entry_points={
        'console_scripts': [
        	'status_publisher = ros2_project_pkg.status_publisher:main',
        	'command_listener = ros2_project_pkg.command_listener:main',
            	'hubpilot_listener = ros2_project_pkg.vehicle_listener:main',
            	'robotarm_listener = ros2_project_pkg.robotarm_listener:main',
        ],
    },
)
